<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Student Data Enter Form</title>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="favicon.png" />



<style type="text/css">
<!--
a:link {
	color: #999999;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #999999;
}
a:hover {
	text-decoration: underline;
	color: #990000;
}
a:active {
	text-decoration: none;
	color: #999999;
}
.style2 {color: #990000}
.style3 {color: #666666}
.style6 {color: #990000; font-size: 11px; }
.style7 {color: #009900}
-->
</style>
</head>

<body class="form2">
<div class="form">
<form action="#" method="post">
  <table width="680" border="0" align="center" cellpadding="10" cellspacing="0" bgcolor="#FFFFFF">
    <tr>
      <td height="44" colspan="2"><div align="center">S<strong>tudent Data Entry Form</strong> - <span class="style2">* All the Fields Are required</span></div></td>
    </tr>
    <tr>
      <td width="291" height="46">School phone number&nbsp;&nbsp; 
        <label>
        <input name="phone_num" type="text" id="phone_num" maxlength="10" />
        </label></td>
      <td width="349"> <span class="style3">School : <span class="style7">[\*SchhoolDisplay be added from php code*\]</span></span></td>
    </tr>
    <tr>
      <td height="41" colspan="2">Date&nbsp;&nbsp;&nbsp;
        <label>
        <select name="date" id="date">
          <option selected="selected">1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
        </select>
&nbsp;&nbsp;
<select name="month" id="month">
  <option selected="selected">January</option>
  <option>February</option>
  <option>March</option>
  <option>April</option>
  <option>May</option>
  <option>June</option>
  <option>July</option>
  <option>August</option>
  <option>September</option>
  <option>October</option>
  <option>November</option>
  <option>December</option>
</select>
&nbsp;&nbsp;
<input name="year" type="text" id="year" size="4" maxlength="4" />
        </label>        <label></label></td>
      </tr>
    <tr>
      <td height="35" colspan="2">Name in full - with the Initials&nbsp;&nbsp;&nbsp; 
        <input name="name_in_full" type="text" id="name_in_full" size="50" /></td>
    </tr>
    <tr>
      <td colspan="2"><label>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input name="name_in_full2" type="text" id="name_in_full2" size="50" />
        <br /><br />
      </label>
      <hr color="#CCCCCC" /></td>
    </tr>
    
    <tr>
      <td colspan="2">Address line 1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input name="add1" type="text" id="add1" size="50" /></td>
    </tr>
    <tr>
      <td colspan="2">Address line 2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input name="add2" type="text" id="add2" size="50" /></td>
    </tr>
    <tr>
      <td height="48" colspan="2"><p>Address line 3&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input name="add3" type="text" id="add3" size="50" />
      </p>
        <hr color="#CCCCCC" /></td>
    </tr>
    
    <tr>
      <td>Birthday&nbsp;&nbsp;&nbsp;
        <label>
        <select name="date" id="date">
          <option selected="selected">1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
        </select>
&nbsp;&nbsp;
<select name="month" id="month">
  <option selected="selected">January</option>
  <option>February</option>
  <option>March</option>
  <option>April</option>
  <option>May</option>
  <option>June</option>
  <option>July</option>
  <option>August</option>
  <option>September</option>
  <option>October</option>
  <option>November</option>
  <option>December</option>
</select>
&nbsp;&nbsp;
<input name="year2" type="text" id="year2" size="4" maxlength="4" />
        </label>
        <label></label></td>
      <td><strong>Gender</strong>&nbsp;&nbsp;&nbsp;
        <label>
        <input type="radio" name="gender" id="radio" value="radio" />
        Male&nbsp;&nbsp;&nbsp;
        <input type="radio" name="gender" id="radio2" value="radio2" />
        Female</label></td>
    </tr>
    <tr>
      <td height="63" colspan="2"><hr color="#CCCCCC" />
        <p>Class&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          <label>
          <input type="text" name="class" id="class" />
          </label>
          <em><span class="style6"> &nbsp;&nbsp;&nbsp;*important - Add your class correctlly and careffully according to your details</span></em></p>        </td>
    </tr>
    <tr>
      <td colspan="2">Blood Grouop (compulsary)&nbsp;&nbsp;
        <label>
        <input name="bllod" type="text" id="bllod" size="5" />
        &nbsp;&nbsp;&nbsp;Eye color 
        <input name="eye" type="text" id="eye" size="15" />
        &nbsp;&nbsp;Allergy&nbsp;&nbsp;&nbsp; 
        <input name="textfield" type="text" id="textfield" size="20" />
        </label></td>
    </tr>
    <tr>
      <td colspan="2">Mother's Day&nbsp;&nbsp;&nbsp;
        <label>
        <input name="mth_name" type="text" id="mth_name" size="60" />
        </label></td>
    </tr>
    <tr>
      <td colspan="2">Father's Day&nbsp;&nbsp;&nbsp;
        <label>
        <input name="fth_name" type="text" id="fth_name" size="60" />
        </label></td>
    </tr>
    <tr>
      <td colspan="2">In Emergency : Contact numbers (Both Father &amp; Moother )</td>
    </tr>
    <tr>
      <td height="65" colspan="2">Mobile : 
        <label>
        <input name="em_num" type="text" id="em_num" maxlength="10" />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mobile :
        
        <input name="em_num2" type="text" id="em_num2" maxlength="10" />
&nbsp;&nbsp;&nbsp;&nbsp;Home :
<input name="em_num3" type="text" id="em_num3" maxlength="10" />
</label></td>
    </tr>
    <tr>
      <td height="50"><label></label></td>
      <td height="50"><label>
        <input type="submit" name="submit" id="submit" value="Submit Data" />
        <input type="reset" name="Reset" id="button" value="Clear Name" />
      </label></td>
    </tr>
    
    <tr>
      <td colspan="2"><span class="style7">[\*add php here to validate that Data successfully added or not*\]</span></td>
    </tr>
  </table>



</form>



</div>
</body>
</html>
