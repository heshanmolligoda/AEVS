<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Official Student Database of Sri Lankan Schools - powered by Schoolpro™</title>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="favicon.png" />
<script type="text/javascript">

function theChecker()
{
if(document.regi.check.checked==false)
{
document.regi.record.disabled=true;
}
else
{
document.regi.record.disabled=false;
}
}
</script>



<style type="text/css">
<!--
.style1 {
	color: #990000;
	font-weight: bold;
	font-size: 14px;
}
a:link {
	color: #999999;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #999999;
}
a:hover {
	text-decoration: underline;
	color: #990000;
}
a:active {
	text-decoration: none;
	color: #999999;
}
.style2 {
	color: #666666;
	font-weight: bold;
}
-->
</style>
</head>

<body>

<div id="header">
  <div class="logo"><img src="images/logo.png" /></div>
    
  </div>
<div class="main_container">
  <div class="container_register">
<form target="_parent" action="index.php" name="regi" id="regi">
  <table width="900px" border="0" cellpadding="5" cellspacing="0">
    <tr>
      <td height="35" colspan="2"><p class="style2">&nbsp;&nbsp;&nbsp;&nbsp;Basic Information about the Academy / School</p>        </td>
      <td width="347"><span class="style2">&nbsp;&nbsp;&nbsp;Terms &amp; Conditions</span></td>
    </tr>
    <tr>
      <td width="172" height="42">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name of the School </td>
      <td width="321"><label>
        <input name="school" type="text" id="school" size="50" />
      </label></td>
      <td rowspan="6" valign="top"><label></label>
        <label>
       
        <textarea name="terms" cols="38" rows="15"  id="terms" disabled="disabled">
::Terms and conditions template for website usage::

Welcome to our website. If you continue to browse and use this website, you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern [business name]'s relationship with you in relation to this website. If you disagree with any part of these terms and conditions, please do not use our website.

The term '[business name]' or 'us' or 'we' refers to the owner of the website whose registered office is [address]. Our company registration number is [company registration number and place of registration]. The term 'you' refers to the user or viewer of our website.

The use of this website is subject to the following terms of use:

    The content of the pages of this website is for your general information and use only. It is subject to change without notice.
    This website uses cookies to monitor browsing preferences. If you do allow cookies to be used, the following personal information may be stored by us for use by third parties: [insert list of information].
    Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.
    Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.
    This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.
    All trade marks reproduced in this website which are not the property of, or licensed to, the operator are acknowledged on the website.
    Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.
    From time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).
    Your use of this website and any dispute arising out of such use of the website is subject to the laws of England, Northern Ireland, Scotland and Wales.
</textarea>
        <br />
        <br />
        <input type="checkbox" name="check" id="checkbox" onclick="theChecker()" />
        I have read and accepted above terms.
        <br />
        <br />
        </label></td>
    </tr>
    <tr>
      <td height="35">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Related Division</td>
      <td height="35"><label>
        <select name="province" id="province">
          <option>Select your Devision..</option>
          <option>Central Province</option>
          <option>Easternl Province</option>
          <option>North Central Province</option>
          <option>Northern Province</option>
          <option>North Western Province</option>
          <option>Sabaragamuwa Province</option>
          <option>Southern Province</option>
          <option>Uva Province</option>
          <option>Western Province</option>
        </select>
      </label></td>
      </tr>
    <tr>
      <td height="35">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Related District</td>
      <td><select name="district" id="district">
        <option>Select your District..</option>
        <option>Ampara</option>
        <option>Anuradhapura</option>
        <option>Badulla</option>
        <option>Batticaloa</option>
        <option>Colombo</option>
        <option>Galle</option>
        <option>Gampaha</option>
        <option>Hambantota</option>
        <option>Jaffna</option>
        <option>Kalutara</option>
        <option>Kandy</option>
        <option>Kegalle</option>
        <option>Kilinochchi</option>
        <option>Kurunegala</option>
        <option>Mannar</option>
        <option>Matale</option>
        <option>Matara</option>
        <option>Moneragala</option>
        <option>Mullaitivu</option>
        <option>Nuwara Eliya</option>
        <option>Polonnaruwa</option>
        <option>Puttalam</option>
        <option>Ratnapura</option>
        <option>Trincomalee</option>
        <option>Vavuniya</option>
            </select></td>
      </tr>
    <tr>
      <td height="35">&nbsp;&nbsp;&nbsp;&nbsp;Name of the Principle</td>
      <td><input name="principle" type="text" id="principle" size="50" maxlength="10" /></td>
    </tr>
    <tr>
      <td height="103">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Postal Address</td>
      <td><label>
        <textarea name="add" id="add" cols="40" rows="5"></textarea>
      </label></td>
      </tr>
    <tr>
      <td height="79">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Contact Number</td>
      <td><label>
        <input name="official" type="text" id="official" maxlength="10" />
      Official<br />
      <br />
      <input type="text" name="mobile" id="mobile" />
      Mobile (if there is)</label></td>
      </tr>
    <tr>
      <td height="44">&nbsp;</td>
      <td><input name="fax" type="text" id="fax" maxlength="10" /> 
        Fax</td>
      <td><label>
        <input type="submit" name="record" id="button" value="Submit details" disabled="disabled" />
      &nbsp;&nbsp;
      <input type="submit" name="cancel" id="button2" value="Cancel" />
      &nbsp;&nbsp;
      <input type="submit" name="clear" id="button3" value="Clear the record" />
      </label></td>
    </tr>
    <tr>
      <td height="32">&nbsp;&nbsp;&nbsp;&nbsp;E - mail</td>
      <td height="32"><input name="email" type="text" id="email" size="50" maxlength="10" /></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</div>
</div>

<div class="footer_register">
  <p>Programme conducted by :<br />
  Department of Education</p>
  <p>Technology Partner : <strong>Studentpro Education System</strong> created by Infortec Technology Solutions™&nbsp;&nbsp;</p>
  <p>IT partner&nbsp;: Infortec Technology Solutions ™</p>
  <p align="center"><img src="images/its.png" alt="Infortec Technology Solutions" width="50" height="38" /><br />
  copyright @ ITS </p>
</div>
</body>
</html>
