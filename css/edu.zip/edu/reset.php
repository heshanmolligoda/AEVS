<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reset Your Username or Password</title>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="favicon.png" />
<style type="text/css">
<!--
.style1 {
	color: #990000;
	font-weight: bold;
}
.style2 {color: #FF0000}
-->
</style>
</head>

<body>
<div class="reset_container">
  <p>Enter your Username or password below field and enter the valid e-mail address underneath. After that press the &quot;Resett&quot; button to get your user name or password.</p>
  <table width="400" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="28">Enter the Username</td>
      <td><label>
        <input type="text" name="textfield" id="textfield" />
      </label></td>
    </tr>
    <tr>
      <td height="25" colspan="2"><div align="center" class="style1">Or </div></td>
    </tr>
    <tr>
      <td height="38">Enter the Password</td>
      <td><label>
        <input type="text" name="textfield2" id="textfield2" />
      </label></td>
    </tr>
    <tr>
      <td height="30">Enter the E-Mail<span class="style2"> *</span></td>
      <td><label>
        <input name="textfield3" type="text" id="textfield3" size="35" />
      </label></td>
    </tr>
    <tr>
      <td height="31">&nbsp;</td>
      <td><label>
        <input type="submit" name="button" id="button" value="Reset" />
      </label>
      &nbsp;&nbsp;&nbsp;
      <label>
      <input type="submit" name="button2" id="button2" value="Clear" />
      </label></td>
    </tr>
    <tr>
      <td height="38" colspan="2">
      
      <!--this div is for validation-->
      <div></div>
      <!--validate_end-->
      </td>
    </tr>
  </table>
  <p class="style2">* Make sure you are giving the correct and valid E-mail address that you &nbsp;&nbsp;&nbsp;used when you are register.</p>
  <span class="style2">* Your details are stored in database in highly secure storage.</span></div>
</body>
</html>
