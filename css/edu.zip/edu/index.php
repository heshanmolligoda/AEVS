<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Official Student Database of Sri Lankan Schools - powered by Schoolpro™</title>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="favicon.png" />
<style type="text/css">
<!--
.style1 {
	color: #990000;
	font-weight: bold;
	font-size: 14px;
}
.style2 {
	color: #990000;
	font-weight: bold;
}
a:link {
	color: #999999;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #999999;
}
a:hover {
	text-decoration: underline;
	color: #990000;
}
a:active {
	text-decoration: none;
	color: #999999;
}
.style3 {color: #666666}
.style4 {color: #990000}
-->
</style>
</head>

<body>

<div id="header">
  <div class="logo">
    <div align="center"><img src="images/logo.png" width="446" height="140" /></div>
  </div>
    
    </div>
<div class="under_text style3">Department of Education - associated ministry&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#">Read The details of the Project</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#">Get the Detail Sheet about the registration</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;<span class="style4">Welcome ( User )</span></div>

<div class="main_container">
<div id="link_list">
  <p class="style1">Student Pro featured :</p>
  <ul>
    <li><a href="#">About StudentPro&nbsp;</a><br />
      <br />
</li>
    <li> <a href="#">Coordination details</a><br />
      <br />
    </li>
    <li><a href="#">School list</a><br />
      <br />
    </li>
    <li><a href="register.php">School Registration</a><br />  
      <br />
    </li>
    <li><a href="#">Check Database</a><br />
      <br />
</li>
    <li><a href="#">Privilages<br />
      </a><br />
    </li>
    <li><a href="#">Resource people<br />
      </a><br />
    </li>
    <li><a href="#">Documentation<br />
      </a><br />
    </li>
    <li><a href="#">Privacy policy</a><br />
      <br />
      <br />
    </li>
  </ul>
  <p>&nbsp;</p>
</div>

<div id="container">
<form target="_parent" action="dashboard_admin.php">
<table width="500" border="0" cellspacing="0" cellpadding="12">
  <tr>
    <td height="24" colspan="2"><div align="center">
      <p class="style2">&nbsp;</p>
      <p class="style2">Sri Lankan Student database system User Login</p>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Username</div></td>
    <td><label>
      <input type="text" name="user" id="user" />
    </label></td>
  </tr>
  <tr>
    <td><div align="right">Password</div></td>
    <td><label>
      <input name="textfield2" type="password" id="password" maxlength="20" />
    </label></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center">
      <label>

          <div align="left">
            <input type="submit" name="login" id="login" value="Login" />
            </label>
            </div>
    </div></td>
  </tr>
  <tr>
    <td colspan="2"><div align="right">Forgot Your username or password?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <a href="reset.php" onclick="window.open('reset.php','popup','width=500,height=500,scrollbars=no,resizable=no,toolbar=no,directories=no,location=no,menubar=no,status=no,left=400px,top=150px'); return false"><br />
      Get your username or password from here..</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div></td>
    </tr>
</table>
</form>
</div>
</div>
<div class="footer">
  <p>Programme conducted by :<br />
  Department of Education</p>
  <p>Technology Partner : <strong>Studentpro Education System</strong> created by Infortec Technology Solutions™&nbsp;&nbsp;</p>
  <p>IT partner&nbsp;: Infortec Technology Solutions ™</p>
  <p align="center"><img src="images/its.png" alt="Infortec Technology Solutions" width="50" height="38" /><br />
  copyright @ ITS </p>
 

</div>
</body>
</html>
