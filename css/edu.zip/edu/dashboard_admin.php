<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Official Student Database of Sri Lankan Schools - powered by Schoolpro™</title>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" href="favicon.png" />
<script type="text/javascript">

function theChecker()
{
if(document.regi.check.checked==false)
{
document.regi.record.disabled=true;
}
else
{
document.regi.record.disabled=false;
}
}
</script>



<style type="text/css">
<!--
.style1 {
	color: #990000;
	font-weight: bold;
	font-size: 14px;
}
a:link {
	color: #999999;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #999999;
}
a:hover {
	text-decoration: underline;
	color: #990000;
}
a:active {
	text-decoration: none;
	color: #999999;
}
-->
</style>
</head>

<body>

<div id="header">
  <div class="logo"><img src="images/logo.png" /></div>
    
  </div>
<div class="main_container">
  <div id="link_list">
    <p class="style1">Student Pro featured :</p>
    <ul>
      <li><a href="#">About StudentPro&nbsp;</a><br />
          <br />
      </li>
      <li> <a href="#">Coordination details</a><br />
          <br />
      </li>
      <li><a href="#">School list</a><br />
          <br />
      </li>
      <li><a href="register.php">School Registration</a><br />
          <br />
      </li>
      <li><a href="#">Check Database</a><br />
          <br />
      </li>
      <li><a href="#">Privilages<br />
        </a><br />
      </li>
      <li><a href="#">Resource people<br />
        </a><br />
      </li>
      <li><a href="#">Documentation<br />
        </a><br />
      </li>
      <li><a href="#">Privacy policy</a><br />
          <br />
          <br />
      </li>
    </ul>
    <p>&nbsp;</p>
  </div>
  <!--dashboard-->
  <div id="dash_admin">
    <p><strong>Welcome</strong> ( User name after logging -else it will be guest)<br />
    Date &lt;dd-mm-yyyy&gt;<br />
    </p>
    <p><strong>Administrator Dashboard</strong></p>
    <p><img src="images/dash.png" width="340" height="70" border="0" usemap="#Map" />
<map name="Map" id="Map">
  <area shape="rect" coords="27,8,86,61" href="#" />
  <!--data entry section-->
  <area shape="rect" coords="139,7,199,62" href="form.php" target="_blank"/>
  
  <area shape="rect" coords="249,8,312,62" href="#" />
</map></p>
    <p><img src="images/red-arrow-right.GIF" width="19" height="15" /><a href="index.php"> Back to home</a></p>
    <p><img src="images/red-arrow-right.GIF" alt="" width="19" height="15" /> <a href="#">Your Preferences</a></p>
    <p><img src="images/red-arrow-right.GIF" alt="" width="19" height="15" /><a href="#"> Data Analysis</a></p>
  </div>
  
</div>

<div class="footer_register">
  <p>Programme conducted by :<br />
  Department of Education</p>
  <p>Technology Partner : <strong>Studentpro Education System</strong> created by Infortec Technology Solutions™&nbsp;&nbsp;</p>
  <p>IT partner&nbsp;: Infortec Technology Solutions ™</p>
  <p align="center"><img src="images/its.png" alt="Infortec Technology Solutions" width="50" height="38" /><br />
  copyright @ ITS </p>
</div>
</body>
</html>
